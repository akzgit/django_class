from django.shortcuts import render
from .forms import UploadForm
from django.views.generic.base import View
from io import TextIOWrapper
from csv import DictReader
from .forms import ProductForm,UploadForm

# Create your views here.
class UploadView(View):
    def get(self,request):
        return render(request,"upload.html",{'form':UploadForm()})
    
    def post(self,request):
        product_file = request.FILES["product_file"]
        rows = TextIOWrapper(product_file,encoding="utf-8", newline="")
        row_count=0
        form_errors = []
        for row in DictReader(rows):
            row_count+=1
            form = ProductForm(row)
            if not form.is_valid():
                form_errors = form.errors
                break
            form.save()
        return render(request,"upload.html",{"form":UploadForm(), "form_errors":form_errors,"row_count":row_count})

